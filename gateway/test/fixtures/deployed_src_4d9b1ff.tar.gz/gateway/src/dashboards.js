// Dashboard and report model. A panel is DATA, not pixels: {id,title,type,state,source,accuracy,data,empty_reason,limitations}. Flutter, GuardOps or the offline HTML renderer all consume the
// same JSON. Missing data is an explicit state (NO_DATA, NOT_APPLICABLE, ...) with a reason, never a zero. Sandbox/synthetic data is never mixed into these (production tables only).
import { kpis } from './kpi.js';
import { downloadSummary } from './gh_collector.js';
import { costSummary, unitCosts } from './cost.js';
import { crmSummary } from './crm.js';
import { evaluateAlerts } from './alerts.js';
import { iso, HttpError } from './util.js';

export const DASHBOARDS = ['overview', 'downloads', 'api', 'premium', 'cost', 'crm'];
const panel = (id, title, type, state, source, data, { accuracy = null, reason = null, limitations = null } = {}) => ({ id, title, type, state, source, accuracy, data: state === 'NO_DATA' || state === 'NOT_INSTRUMENTED' || state === 'NOT_APPLICABLE' || state === 'NOT_YET_OBSERVABLE' ? null : data, empty_reason: reason, limitations });
const fromKpi = (k, id, title, type, source, shape = (v) => v) => panel(id, title, type, k.state, source, k.value === null ? null : shape(k.value), { accuracy: k.accuracy, reason: k.note ?? (k.value === null ? k.state.toLowerCase().replace(/_/g, ' ') : null) });

export async function dashboard(db, clock, id, { tenantId = null, period = null, mode = 'FREE_LAUNCH' } = {}) {
  if (!DASHBOARDS.includes(id)) throw new HttpError(404, 'not_found', 'Unknown dashboard.');
  const now = clock(), month = period ?? now.toISOString().slice(0, 7), k = await kpis(db, clock, { tenantId, mode }), panels = [];
  if (id === 'overview') {
    const gh = tenantId ? null : await downloadSummary(db, clock, { windowDays: 30 }), al = tenantId ? null : await evaluateAlerts(db, clock);
    panels.push(fromKpi(k.dau, 'dau', 'Active API clients today (keys, not people)', 'value', 'activity_daily', (v) => v), fromKpi(k.mau, 'mau', 'Active API clients, 30 days', 'value', 'activity_daily'), fromKpi(k.active_orgs_30d, 'orgs', 'Active organisations, 30 days', 'value', 'activity_daily'),
      fromKpi(k.requests_by_channel, 'requests', 'Requests by channel, 30 days', 'bar', 'analytics_daily'), fromKpi(k.premium_actors_30d, 'premium', 'Premium clients (free during FREE_LAUNCH), 30 days', 'value', 'activity_daily'),
      fromKpi(k.billed_micros, 'billed', 'Revenue actually billed (micro-units)', 'value', 'analytics_daily'));
    panels.push(gh ? panel('downloads30', 'YARA bundle downloads observed, 30 days', 'value', gh.last_status === 'never_run' ? 'NO_DATA' : gh.coverage_of_window < 1 ? 'PARTIAL_COVERAGE' : 'REAL_VERIFIED', 'github_release_download_count', { observed: gh.totals.bundle_downloads_observed_in_window, coverage: gh.coverage_of_window }, { accuracy: gh.accuracy.observed, reason: gh.last_status === 'never_run' ? 'the collector has not run' : null, limitations: gh.limitations })
      : panel('downloads30', 'YARA bundle downloads', 'value', 'NOT_APPLICABLE', 'github', null, { reason: 'public releases are not tenant data' }));
    if (al) panels.push(panel('alerts', 'Alerts firing', 'list', 'REAL_VERIFIED', 'alerts', al.alerts.filter((a) => a.state === 'FIRING'), { reason: al.firing ? null : `none firing; ${al.alerts.filter((a) => a.state === 'INSUFFICIENT_DATA').length} of ${al.alerts.length} rules cannot be judged yet (insufficient data)` }));
  }
  if (id === 'downloads') {
    if (tenantId) panels.push(panel('gh', 'GitHub downloads', 'table', 'NOT_APPLICABLE', 'github', null, { reason: 'public releases are not tenant data' }));
    else { const gh = await downloadSummary(db, clock, { windowDays: 30 }), none = gh.last_status === 'never_run';
      panels.push(panel('collector', 'Collector health', 'value', none ? 'NO_DATA' : gh.consecutive_failures ? 'QUERY_ERROR' : 'REAL_VERIFIED', 'gh_sync', { last_success_at: gh.last_success_at, staleness_seconds: gh.staleness_seconds, coverage_of_window: gh.coverage_of_window, consecutive_failures: gh.consecutive_failures }, { reason: none ? 'the collector has not run' : null }),
        panel('releases', 'Releases: bundle downloads (cumulative vs observed)', 'table', none ? 'NO_DATA' : 'REAL_VERIFIED', 'gh_assets, gh_observations', gh.releases, { accuracy: gh.accuracy.observed, reason: none ? 'the collector has not run' : null, limitations: gh.limitations }),
        panel('kinds', 'Assets by kind (never summed as bundle downloads)', 'bar', none ? 'NO_DATA' : 'REAL_VERIFIED', 'gh_assets', gh.by_asset_kind, { accuracy: 'EXACT' })); }
    const c = (await db.prepare('SELECT release_tag, asset_name, actor_kind, SUM(redirected) n FROM community_requests_daily WHERE day >= ? GROUP BY release_tag, asset_name, actor_kind ORDER BY n DESC LIMIT 50').bind(iso(new Date(now.getTime() - 30 * 864e5)).slice(0, 10)).all()).results;
    panels.push(panel('redirects', 'Community redirects issued via the gateway route (NOT completed downloads), 30 days', 'table', c.length ? 'REAL_VERIFIED' : 'NO_DATA', 'community_requests_daily', c, { accuracy: 'EXACT', reason: c.length ? null : 'no redirect has been issued through the gateway', limitations: 'The public URLs on GitHub bypass this route; GitHub and gateway figures are separate and are not added together.' }));
    const dl = await db.prepare(`SELECT state, COUNT(*) n FROM downloads${tenantId ? ' WHERE tenant_id = ?' : ''} GROUP BY state`).bind(...(tenantId ? [tenantId] : [])).all().then((r) => r.results);
    panels.push(panel('premium_downloads', 'Premium downloads by state', 'bar', dl.length ? 'REAL_VERIFIED' : 'NO_DATA', 'downloads', dl, { accuracy: 'EXACT', reason: dl.length ? null : 'no Premium download recorded', limitations: 'COMPLETED only when the delivered byte ranges cover the whole file.' }));
  }
  if (id === 'api') {
    panels.push(fromKpi(k.requests_by_channel, 'requests', 'Requests by channel, 30 days', 'bar', 'analytics_daily'), fromKpi(k.error_rate, 'errors', 'Server-side error rate, 30 days', 'value', 'analytics_daily'), fromKpi(k.latency_ms, 'latency', 'Latency p50/p95/p99 (estimated)', 'value', 'analytics_daily buckets'), fromKpi(k.units_consumed, 'units', 'Metered units consumed', 'value', 'analytics_daily'));
    const top = (await db.prepare(`SELECT operation, channel, SUM(requests) requests, SUM(CASE WHEN status_class IN ('5xx','tool_error') THEN requests ELSE 0 END) errors FROM analytics_daily WHERE day >= ?${tenantId ? ' AND tenant_id = ?' : ''} GROUP BY operation, channel ORDER BY requests DESC LIMIT 20`).bind(iso(new Date(now.getTime() - 30 * 864e5)).slice(0, 10), ...(tenantId ? [tenantId] : [])).all()).results;
    panels.push(panel('top_ops', 'Most used operations / MCP tools, 30 days', 'table', top.length ? 'REAL_VERIFIED' : 'NO_DATA', 'analytics_daily', top, { accuracy: 'EXACT', reason: top.length ? null : 'no requests recorded' }));
  }
  if (id === 'premium') panels.push(fromKpi(k.premium_actors_30d, 'actors', 'Premium clients, 30 days (usage, not payment)', 'value', 'activity_daily'), fromKpi(k.premium_orgs_30d, 'orgs', 'Premium organisations, 30 days', 'value', 'activity_daily'), fromKpi(k.premium_adoption_rate, 'rate', 'Premium share of active clients', 'value', 'activity_daily'),
    fromKpi(k.paid_customers, 'paid', 'Paying customers', 'value', 'tenants'), fromKpi(k.funnel, 'funnel', 'Conversion funnel (tenants)', 'table', 'tenants, activity', (v) => Object.entries(v).map(([state, x]) => ({ state, ...x }))),
    fromKpi(k.retention_d30, 'ret30', 'D30 retention', 'value', 'actor_first_seen'), fromKpi(k.monthly_retention, 'retm', 'Monthly retention', 'value', 'activity_daily'), fromKpi(k.recurring_actors_30d, 'recurring', 'Recurring clients, 30 days', 'value', 'activity_daily'));
  if (id === 'cost') {
    const s = await costSummary(db, { period: month, tenantId }), u = await unitCosts(db, month);
    panels.push(panel('lines', `Costs ${month} by provider/service`, 'table', s.state, 'cost_entries', s.lines, { accuracy: 'RECONCILED', reason: s.state === 'NO_DATA' ? 'no invoice imported and no rate configured' : null, limitations: s.note }),
      panel('totals', 'Totals by currency', 'value', s.state, 'cost_entries', s.totals_by_currency, { accuracy: 'EXACT' }), panel('unit', 'Unit cost per 1000 requests', 'value', u.unit_costs[0].value === null ? 'NO_DATA' : 'REAL_VERIFIED', 'cost_entries, analytics_daily', u.unit_costs, { accuracy: u.unit_costs[0].accuracy ?? null, reason: u.unit_costs[0].reason ?? null }),
      fromKpi(k.theoretical_value_micros, 'theoretical', 'Theoretical value at example prices (NOT revenue)', 'value', 'analytics_daily'), fromKpi(k.billed_micros, 'billed', 'Billed (real revenue)', 'value', 'analytics_daily'));
    panels.push(panel('stripe', 'Stripe sandbox', 'value', 'NOT_INSTRUMENTED', 'stripe', null, { reason: 'sandbox credentials are not configured; no Stripe data is shown or simulated' }));
  }
  if (id === 'crm') {
    if (tenantId) panels.push(panel('crm', 'CRM', 'table', 'NOT_APPLICABLE', 'leads', null, { reason: 'the CRM is platform-level' }));
    else { const c = await crmSummary(db); panels.push(panel('pipeline', 'Pipeline by current state', 'bar', c.state, 'leads', c.current, { accuracy: 'EXACT', reason: c.state === 'NO_DATA' ? 'no lead has been recorded' : null, limitations: c.note }), panel('reached', 'Leads that ever reached each state', 'bar', c.state, 'lead_events', c.ever_reached, { accuracy: 'EXACT' }), panel('win', 'Win rate (WON / (WON + LOST))', 'value', c.win_rate === null ? 'NO_DATA' : 'REAL_VERIFIED', 'lead_events', c.win_rate, { accuracy: 'EXACT' })); }
  }
  return { schema: 'macguard.dashboard/1', id, scope: tenantId ? { tenant_id: tenantId } : { platform: true }, mode, generated_at: iso(now), panels };
}

// ---- reports: a period + a set of dashboards, rendered as JSON, CSV or HTML. Every section repeats its source, accuracy and limitations. ---------------------------------------------------
const PLAN = { daily: ['downloads', 'api'], weekly: ['overview', 'premium'], monthly: ['cost', 'premium', 'crm'] };
export async function report(db, clock, kind, opts = {}) {
  if (!PLAN[kind]) throw new HttpError(400, 'invalid_input', 'kind must be daily, weekly or monthly.');
  const now = clock(), day = now.toISOString().slice(0, 10), periodOf = { daily: { from: day, to: day }, weekly: { from: new Date(now.getTime() - 6 * 864e5).toISOString().slice(0, 10), to: day }, monthly: { month: day.slice(0, 7) } }[kind];
  const sections = []; for (const id of PLAN[kind]) sections.push(await dashboard(db, clock, id, opts));
  return { schema: 'macguard.report/1', kind, period: periodOf, generated_at: iso(now), scope: opts.tenantId ? { tenant_id: opts.tenantId } : { platform: true }, note: 'Figures are as of generation time; windows inside each panel are stated in its title/source.', sections };
}
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);
const flat = (v, p = '') => (v !== null && typeof v === 'object' ? Object.entries(v).flatMap(([k, x]) => flat(x, p ? `${p}.${k}` : k)) : [[p, v]]);
const csvCell = (v) => { let s = String(v ?? ''); if (/^[=+\-@\t\r]/.test(s)) s = "'" + s; return /[",\n\r]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s; };       // leading =,+,-,@ neutralised (CSV injection)
export function toCsv(rep) {
  const lines = [['dashboard', 'panel', 'state', 'accuracy', 'source', 'key', 'value'].join(',')];
  for (const s of rep.sections ?? [rep]) for (const p of s.panels) { const kv = p.data === null || p.data === undefined ? [['', '']] : flat(p.data); for (const [k, v] of kv) lines.push([s.id, p.id, p.state, p.accuracy, p.source, k, v].map(csvCell).join(',')); }
  return lines.join('\n') + '\n';
}
export function toHtml(rep) {
  const sections = rep.sections ?? [rep], title = rep.kind ? `MacGuard ${rep.kind} report` : `MacGuard dashboard: ${rep.id}`;
  const body = sections.map((s) => `<section><h2>${esc(s.id)}</h2>${s.panels.map((p) => `<article class="p ${esc(p.state)}"><h3>${esc(p.title)}</h3><p class="m"><b>${esc(p.state)}</b> · ${esc(p.source)}${p.accuracy ? ' · ' + esc(p.accuracy) : ''}</p>${p.data === null || p.data === undefined ? `<p class="e">${esc(p.empty_reason ?? 'no data')}</p>` : `<table>${flat(p.data).map(([k, v]) => `<tr><th>${esc(k)}</th><td>${esc(v)}</td></tr>`).join('')}</table>`}${p.limitations ? `<p class="l">${esc(p.limitations)}</p>` : ''}</article>`).join('')}</section>`).join('');
  return `<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${esc(title)}</title><style>:root{--bg:#fff;--fg:#1a1a1a;--mu:#666;--bd:#ddd;--gr:#e6e6e6}@media(prefers-color-scheme:dark){:root{--bg:#161616;--fg:#eee;--mu:#aaa;--bd:#333;--gr:#2a2a2a}}body{background:var(--bg);color:var(--fg);font:15px/1.4 system-ui;margin:16px;max-width:1000px}.p{border:1px solid var(--bd);border-radius:8px;padding:10px 14px;margin:10px 0}.p.NO_DATA,.p.NOT_APPLICABLE,.p.NOT_INSTRUMENTED,.p.NOT_YET_OBSERVABLE{background:var(--gr)}.m,.l,.e{color:var(--mu);margin:.2em 0}table{border-collapse:collapse;width:100%}th,td{text-align:left;border-top:1px solid var(--bd);padding:3px 6px;word-break:break-word}th{font-weight:500;color:var(--mu)}</style></head><body><h1>${esc(title)}</h1><p class="m">Generated ${esc(rep.generated_at)} · ${esc(JSON.stringify(rep.scope))}${rep.period ? ' · ' + esc(JSON.stringify(rep.period)) : ''}</p>${body}</body></html>`;
}
